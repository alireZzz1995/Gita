document.addEventListener("DOMContentLoaded" ,function() {
    setTimeout(function(){
        document.getElementById('lodingScreen').style.display = 'none';
        document.getElementById('divlodest').style.display = 'block';
    },3000);
});



// سرچ باکس

let data = [
    {
        "ردیف" :' ',
        "نام" :' ',
        "نام خانوادگی" :' ',
        "کد ملی" :' ',
    }
];

function searchTable() {
    let seaechrowmovemodal = document.getElementById('modalsearchdivId');
    let modalsearchTableBody = document.querySelector("#shearchTable tbody");
    modalsearchTableBody.innerHTML = '';

    let searchInput1 = document.getElementById('searchInput1').value.toLowerCase();
    let searchInput2 = document.getElementById('searchInput2').value.toLowerCase();
    let searchInput3 = document.getElementById('searchInput3').value.toLowerCase();
    let tabledataBase = document.getElementById('tabledataBase');
    let tr = tabledataBase.getElementsByTagName('tr');

    let rowIndex = 0;
    let found = false;
    for (let i = 1 ; i < tr.length; i++){
        
        let firstName = tr[i].getElementsByTagName('td')[1];
        let lastname = tr[i].getElementsByTagName('td')[2];
        let Numberkod = tr[i].getElementsByTagName('td')[3];

        let firstNameValue = firstName ? firstName.textContent.toLowerCase() : '';
        let lastnameValue = lastname ? lastname.textContent.toLowerCase() : '';
        let NumberkodValue = Numberkod ? Numberkod.textContent.toLowerCase() : '';

        
        if (firstNameValue.indexOf(searchInput1) > -1 && lastnameValue.indexOf(searchInput2) > -1 && NumberkodValue.indexOf(searchInput3) > -1) {
            rowIndex++
            let nRow = document.createElement("tr");

           

            let newRowIndexCell = document.createElement("td");
            newRowIndexCell.textContent = rowIndex;
            nRow.appendChild(newRowIndexCell);

            let newNameCell = document.createElement("td");
            newNameCell.textContent = firstNameValue;
            nRow.appendChild(newNameCell);

            let newFullCell = document.createElement("td");
            newFullCell.textContent = lastnameValue;
            nRow.appendChild(newFullCell);

            let newNumberCell = document.createElement("td");
            newNumberCell.textContent = NumberkodValue;
            nRow.appendChild(newNumberCell);


            let activCell = document.createElement("td");
            let ButtonShowitem = document.createElement("button");
            ButtonShowitem.innerHTML = '<i class="fa fa-eye" style="font-size:24px ; color:rgb(0, 60, 255)"></i>';
            ButtonShowitem.style ="background-color: transparent; border: none; cursor: pointer;width: 100%;"

            
            ButtonShowitem.onclick = function(){
                
                scrollToRow(i);
                seaechrowmovemodal.style.display = "none";

            };
            activCell.appendChild(ButtonShowitem);
            nRow.appendChild(activCell);

            modalsearchTableBody.appendChild(nRow);

            found = true ;
            
            
        }  
    }
    if (!found){
        alert('موردی یافت نشد');

        setTimeout(function(){
            
            
            document.getElementById('searchInput1').value ='';
            document.getElementById('searchInput2').value ='';
            document.getElementById('searchInput3').value ='';
            
           
        }, 30);
    } else {
        openMssearch();   
    }
    function openMssearch(){
        let searchmodal = document.getElementById('modalsearchdivId');
        searchmodal.style.display = "block";
    }

    

}

function scrollToRow(rowIndex){
    let moveTable = document.getElementById('tabledataBase');
    let rowMove = moveTable.getElementsByTagName('tr')[rowIndex];

    rowMove.classList.add('highlight');

    rowMove.scrollIntoView({behavior: "smooth"});


    setTimeout(function(){
        rowMove.classList.remove('highlight');
    },2000);

    document.getElementById('searchInput1').value ='';
    document.getElementById('searchInput2').value ='';
    document.getElementById('searchInput3').value ='';
}


function closeModalsearch() {
    let modalse = document.getElementById("modalsearchdivId");
    document.getElementById('searchInput1').value ='';
    document.getElementById('searchInput2').value ='';
    document.getElementById('searchInput3').value ='';
    modalse.style.display = "none";
    
}

window.onclick = function(event){
    var modalsea = document.getElementById('modal-contentsearch');
    if (event.target == modalsea){
        modalsea.style.display = "none";
    }
}



// افزودن کاربر

document.getElementById("modalAddbutton").onclick = function(){
    document.getElementById("modalAddList").style.display = "block";
}

function closeModalAdd() {
    let modaladd = document.getElementById("modalAddList");
    modaladd.style.display = "none";
    
}

window.onclick = function(event2){
    var modalAddlist = document.getElementById('modalAddList');
    if (event2.target == modalAddlist){
        modalAddlist.style.display = "none";
    }
}



// نقشه


let mapadd = L.map('mapadd').setView([32.4279, 53.6880] , 13);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png' ,{
    maxZoom : 19,
    tileSize : 256,
    zoomOffset : 0,
    minZoom : 1 ,
    maxNativeZoom :18 ,
    crossOrigin : true ,
    
    attribute : '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(mapadd);

let selectedLat , selectedLng;

mapadd.on('click', function(e){
    if (mapadd.hasLayer(window.marker)){
        mapadd.removeLayer(window.marker);
    }
    window.marker = L.marker(e.latlng).addTo(mapadd).bindPopup('Lat: ${e.latlng.lat} , Lng: ${e.latlng.lng}').openPopup();

    selectedLat = e.latlng.lat;
    selectedLng = e.latlng.lng;
    document.getElementById('inputadd4').value = `Lat: ${selectedLat} , Lng: ${selectedLng}`
    
});
function showCurrentLocation(){
    if (navigator.geolocation){
        navigator.geolocation.getCurrentPosition(function(position){
            let lat = position.coords.latitude;
            let lng = position.coords.longitude;

            mapadd.setView([lat, lng], 13);

            if(window.currentMarker){
                mapadd.removeLayer(window.currentMarker);
            }

            window.currentMarker = L.marker([lat , lng]).addTo(mapadd).bindPopup('موقعیت فعلی شما').openPopup();
        },
        function(){
            alert("خطا در دریافت موقعیت شما");
        }
    );
    }
    setTimeout(() => {
        map.invalidateSize();
    }, 200);

} 


// انتقال المان از مدال به جدول

let rowCounter =1 ;

window.onload = function(){
    loadTableData();
}

function researctadd(inputvalueadd){

    let tabledataBaseresearchadd = JSON.parse(localStorage.getItem('tabledataBase')) || [];

    for (let data of tabledataBaseresearchadd) {
        if (data["کد ملی"] === inputvalueadd){

            return true;
        }
    }
    return false;
}




document.getElementById('dataaddform').addEventListener('submit' , function(event){
    event.preventDefault();


    var inputadd1 = document.getElementById('inputadd1').value;
    var inputadd2 = document.getElementById('inputadd2').value;
    var inputadd3 = document.getElementById('inputadd3').value;
    // var inputadd4 = document.getElementById('inputadd4').value;

    document.getElementById("Name").innerHTML = '';
    document.getElementById("NameFull").innerHTML = '';
    document.getElementById("NameNumber").innerHTML = '';


    var persianRegex = /^[\u0600-\u06FF\s]+$/;
    
    var selectedLat = selectedLat;
    var selectedLng = selectedLng;

    var data = {
        "نام" :inputadd1,
        "نام خانوادگی" :inputadd2,
        "کد ملی" :inputadd3,
        "نقشه" : [selectedLat,selectedLng]
        
    };


    
        
    // شروط نام

    if (inputadd1 == ""){
        document.getElementById("Name").innerHTML=
        "** لطفا نام خود را وارد کنید";

        return false;
    }

    if (!persianRegex.test(inputadd1)){
        document.getElementById("Name").innerHTML=
        "** لطفا از حروف فارسی استفاده کنید";

        return false;
    }

    if (inputadd1.length <3 || inputadd1.length >20 ){
        document.getElementById("Name").innerHTML=
        "**لطفا نام خود را درست وارد کنید";

        return false;

    }


    // شروط نام خانوادگی


    if (inputadd2 == ""){
        document.getElementById("NameFull").innerHTML=
        "** لطفا نام خانوادگی خود را وارد کنید";

        return false;
    }

    if (!persianRegex.test(inputadd2)){
        document.getElementById("NameFull").innerHTML=
        "** لطفا از حروف فارسی استفاده کنید";

        return false;
    }

    if (inputadd2.length <3 || inputadd2.length >20 ){
        document.getElementById("NameFull").innerHTML=
        "**لطفا نام خانوادگی خود را درست وارد کنید";

        return false;

    }


    // شروط کد ملی

    if (inputadd3 == ""){
        document.getElementById("NameNumber").innerHTML=
        "** لطفا کد ملی خود را درست وارد کنید";

        return false;
    }

    if (inputadd3.length !=10 ){
        document.getElementById("NameNumber").innerHTML=
        "** لطفا کد ملی خود را درست وارد کنید";

        return false;
    }


    if (inputadd3.substring(0 , 2) !== "00" ){
        document.getElementById("NameNumber").innerHTML=
        "** لطفا کد ملی خود را درست وارد کنید";

        return false;
    }

    if (researctadd(inputadd3)){

        document.getElementById("NameNumber").innerHTML=
        "** کد ملی تکراری است   ";
        return ;
    }
    
    


    saveToLocalStorage(data);
    
    addRowToTable(data);

    document.getElementById('dataaddform').reset();
    document.getElementById("modalAddList").style.display = "none";
});

function saveToLocalStorage(data){
    let tabledataBase = JSON.parse(localStorage.getItem('tabledataBase')) || [];

    tabledataBase.push(data);

    localStorage.setItem('tabledataBase' , JSON.stringify(tabledataBase));
        
}

function loadTableData(data){
    let tabledataBase = JSON.parse(localStorage.getItem('tabledataBase')) || [];

    tabledataBase.forEach((data) =>{
        addRowToTable(data);
    });
}


function addRowToTable(data){
    var table = document.getElementById('tabledataBase').getElementsByTagName('tbody')[0];
    var newRow = table.insertRow();

    var rowNumberCell = newRow.insertCell(0);
    rowNumberCell.innerHTML = rowCounter ;
    rowCounter++;

    Object.keys(data).forEach(function(key , index){
        var cell = newRow.insertCell(index +1);
        cell.innerHTML = data[key];

    });

    var actionsCell = newRow.insertCell(-1);

    // کلید حدف و نمایش نقشه و ویرایش در جدول


    // نقشه

    var mapButton = document.createElement('button');
    mapButton.innerHTML = '<i class="fa fa-map-marker" style="font-size:20px"></i>';
    mapButton.style ="background-color: transparent; border: none; cursor: pointer;width: auto; margin-right: 7%;"
    mapButton.onclick = function(){
        showMapModal(data.selectedLat , data.selectedLng);
    };


    // ادیت

    var editButton = document.createElement('button');
    editButton.innerHTML = '<i class="fa fa-edit" style="font-size:20px"></i>';
    editButton.style ="background-color: transparent; border: none; cursor: pointer;width: auto; margin-right: 7%;"
    editButton.onclick = function(){
        openEditModal(newRow , data);
    };


    // ویرایش

    var deleteButton = document.createElement('button');
    deleteButton.innerHTML = '<i class="fa fa-trash-o" style="font-size:20px"></i>';
    deleteButton.style ="background-color: transparent; border: none; cursor: pointer;width: auto; margin-right: 7%;"
    deleteButton.onclick = function(){
        deleteRow(newRow);
    };

    actionsCell.appendChild(deleteButton);
    actionsCell.appendChild(mapButton);
    actionsCell.appendChild(editButton);

}


// عملکرد باتن حذف


function deleteRow(row) {
    var index = row.rowIndex -1 ;
    row.remove();

    let tableData = JSON.parse(localStorage.getItem('tabledataBase')) || [];
    tableData.splice(index , 1);
    localStorage.setItem('tabledataBase' , JSON.stringify(tableData));

    renumberRows();
}



// عمل کردن باتن نمایش نقشه و اجرای مدال


function showMapModal(lat , lng) {
    var modalShowmap = document.getElementById('modalShowmap');
    modalShowmap.style.display = "block";

    var map= L.map('map').setView([32.4279, 53.6880] , 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png' ,{
        maxZoom : 19,
        tileSize : 256,
        zoomOffset : 0,
        minZoom : 1 ,
        maxNativeZoom :18 ,
        crossOrigin : true ,
        attribute : '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    var marker = L.marker([lat , lng]).addTo(map);
    marker.bindPopup('موقعیت انتخاب شده').openPopup();

    setTimeout(() => {
        map.invalidateSize();
    }, 200);
}


function showMapModalclose() {
    let MapModalclose = document.getElementById("modalShowmap");
    MapModalclose.style.display = "none";
    
}

window.onclick = function(event3){
    var modalShowmapclose = document.getElementById('modalShowmap');
    if (event3.target == modalShowmapclose){
        modalShowmapclose.style.display = "none";
    }
}


// عملکرد باتن ویرایش و اجرای مدال ویرایش

let pervValue;

function openEditModal(row , data){
    selectedRow = row;


    let tableData = JSON.parse(localStorage.getItem('tabledataBase')) || [];
    let index = selectedRow.rowIndex -1;
    let db = tableData[index];
    

    pervValue = db["کد ملی"];
    document.getElementById('editInput1').value = db["نام"];
    document.getElementById('editInput2').value = db["نام خانوادگی"];
    document.getElementById('editInput3').value = pervValue;
    document.getElementById('editInput4').value = db["نقشه"];

    var editModal = document.getElementById('editModal');
    editModal.style.display = "block";

}



function editModalclose() {
    let editModal = document.getElementById("editModal");
    editModal.style.display = "none";
    
}

window.onclick = function(event4){
    var editModalclose = document.getElementById('editModal');
    if (event4.target == editModalclose){
        editModalclose.style.display = "none";
    }
}


// اعمال تغیرات


let mapedit = L.map('mapedit').setView([32.4279, 53.6880] , 13);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png' ,{
    maxZoom : 19,
    tileSize : 256,
    zoomOffset : 0,
    minZoom : 1 ,
    maxNativeZoom :18 ,
    crossOrigin : true ,
    attribute : '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(mapedit);

let editLat , editLng;

mapedit.on('click', function(d){
    if (mapedit.hasLayer(window.marker)){
        mapedit.removeLayer(window.marker);
    }
    window.marker = L.marker(d.latlng).addTo(mapedit).bindPopup('Lat: ${d.latlng.lat} , Lng: ${d.latlng.lng}').openPopup();

    editLat = d.latlng.lat;
    editLng = d.latlng.lng;
    
    document.getElementById('editInput4').value = `Lat: ${editLat} , Lng: ${editLng}`
});
function showCurrentLocation(){
    if (navigator.geolocation){
        navigator.geolocation.getCurrentPosition(function(position){
            let lat = position.coords.latitude;
            let lng = position.coords.longitude;

            mapedit.setView([lat, lng], 13);

            if(window.currentMarker){
                mapedit.removeLayer(window.currentMarker);
            }

            window.currentMarker = L.marker([lat , lng]).addTo(mapedit).bindPopup('موقعیت فعلی شما').openPopup();
        },
        
        function(){
            alert("خطا در دریافت موقعیت شما");
        }
    );
    }
    setTimeout(() => {
        mapedit.invalidateSize();
    }, 200);
} 


function researctedit(inputvalue){

    let tabledataBaseresearch = JSON.parse(localStorage.getItem('tabledataBase')) || [];

    for (let data of tabledataBaseresearch) {
        if (data["کد ملی"] === inputvalue){

            return true;
        }
    }
    return false;
}



document.getElementById('editForm').addEventListener('submit' , function(event){
    event.preventDefault();
    
    var input1 = document.getElementById('editInput1').value;
    var input2 = document.getElementById('editInput2').value;
    var input3 = document.getElementById('editInput3').value;
    var input4 = document.getElementById('editInput4').value;

    var persiaNRegex = /^[\u0600-\u06FF\s]+$/;

    document.getElementById("editName").innerHTML = '';
    document.getElementById("editNameFull").innerHTML = '';
    document.getElementById("editNameNumber").innerHTML = '';


    // شروط نام

    if (input1 == ""){
        document.getElementById("editName").innerHTML=
        "** لطفا نام خود را وارد کنید";

        return false;
    }

   
    if (!persiaNRegex.test(input1)){
        document.getElementById("editName").innerHTML=
        "** لطفا از حروف فارسی استفاده کنید";

        return false;
    }

    if (input1.length <3 || input1.length >20 ){
        document.getElementById("editName").innerHTML=
        "**لطفا نام خود را درست وارد کنید";

        return false;

    }


    // شروط نام خانوادگی


    if (input2 == ""){
        document.getElementById("editNameFull").innerHTML=
        "** لطفا نام خانوادگی خود را وارد کنید";

        return false;
    }

    if (!persiaNRegex.test(input2)){
        document.getElementById("editNameFull").innerHTML=
        "** لطفا از حروف فارسی استفاده کنید";

        return false;
    }

   

    if (input2.length <3 || input2.length >20 ){
        document.getElementById("editNameFull").innerHTML=
        "**لطفا نام خانوادگی خود را درست وارد کنید";

        return false;

    }


    // شروط کد ملی

    if (input3 == ""){
        document.getElementById("editNameNumber").innerHTML=
        "** لطفا کد ملی خود را درست وارد کنید";

        return false;
    }

    if (input3.length !=10 ){
        document.getElementById("editNameNumber").innerHTML=
        "** لطفا کد ملی خود را درست وارد کنید";

        return false;
    }


    if (input3.substring(0 , 2) !== "00" ){
        document.getElementById("editNameNumber").innerHTML=
        "** لطفا کد ملی خود را درست وارد کنید";

        return false;
    }

    if (input3 !== pervValue && researctedit(input3)){

        document.getElementById("editNameNumber").innerHTML=
        "** کد ملی تکراری است   ";
        return false;
    }

    let tableData = JSON.parse(localStorage.getItem('tabledataBase')) || [];
    let index = selectedRow.rowIndex -1;
    

    var selectedLat = selectedLat;
    var selectedLng = selectedLng;

    tableData[index] = {
        "نام" :input1,
        "نام خانوادگی" :input2,
        "کد ملی" :input3,
        "نقشه" :[selectedLat,selectedLng]

    };

    localStorage.setItem('tabledataBase' , JSON.stringify(tableData));

    selectedRow.cells[1].innerHTML = input1;
    selectedRow.cells[2].innerHTML = input2;
    selectedRow.cells[3].innerHTML = input3;
    selectedRow.cells[4].innerHTML = input4;

    document.getElementById('editForm').reset();
    document.getElementById('editModal').style.display = "none";

});





function renumberRows(){
    var table = document.getElementById('tabledataBase').getElementsByTagName('tbody')[0];
    for (var i=0 ; i < table.rows.length ; i++){
        table.rows[i].cells[0].innerHTML = i+1 ;
    }
    rowCounter = table.rows.length + 1;
}















